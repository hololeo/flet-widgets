import time
import threading

class Clock:
    def __init__(self):
        self.isrunning = False
        self.start_time = time.time()
        self.thread1 = threading.Thread (target=self.tick, args=()) 
        self.tickfunction = None
    def setTickFunction (self,fn):
        self.tickfunction = fn
    def onTick (self,fn):
        fn()
    def getTime (self):
        self.now = time.time()
        diff = self.now - self.start_time
        return (diff)
    def tick (self):
        while self.isrunning:
            currentTime = self.getTime()
            self.tickfunction (currentTime)            
            #print (f"clock.tick:{currentTime}")
            time.sleep (1)
    def start (self):
        self.isrunning = True
        self.thread1.start ()
    def stop (self):
        self.isrunning = False
# from ClockClass import Clock
# clock = Clock() 
# clock.start() 


