import random
hacs_actions = [
	"HACS looks around the room",
	"HACS is bored",   
	"HACS mumbles to himself", 
	"HACS is whistling ",     
	"HACS says 'now where did i leave that soldering iron'",   
	"HACS beeps",                
    "HACS is writing an email to his dadabase",
    "HACS is cleaning himself with Coke",
    "HACS looks under the bed",
    "HACS looks at you with curiosity",

]

def gethacsbehaviour ():
    return random.choice (hacs_actions)