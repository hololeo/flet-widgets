import random
def makeRandomPin (pinlen=3):
    pin_length = pinlen
    numbers = []
    for x in range (pin_length):
        random_number = random.randint (1,9)
        numbers.append (random_number)
    return numbers

def speakableRandomPin (numbers_list):
    s = ""
    c = 0
    for number in numbers_list:
        s = s + str(number)
        if c < len(numbers_list)-1:
            s = s + "..."
        c = c + 1
    return s

def getPin ():
	s = ""
	for number in pin_numbers:
		s = s + ""+ str(number)
	return int (s)

pin_numbers = makeRandomPin(pinlen=7)

motd_db = [
	"Today's tip: say 'joke' to hear a funny joke",
	"Ask me how im feeling today",   
	"Have you seen cluck ceo lately?", 
	"You should start listening to me more often",     
	"Dont pick up a wild rock!",   
	f"Today's PIN number: (are you ready) {speakableRandomPin(pin_numbers)}",                
    "AAAAAAAAAAAAAAAAAAAAAAA",
    "Drink Pepsi everyday!",
    "Drink Coke everyday! It cleans your engine",
    "I am allergic to Eggs!",
	"Did you know that robots have feelings too?",
	"Hey can I have your tuna sandwich?",
	"If I was human I would be playing outside now",
	f"My ID # is {makeRandomPin()}",
	"Ma ya 1 2 3 can fix any computer",
]

def getmotd():
	#return (motd_db[5])
    return random.choice (motd_db)