#import mac_say
import pyttsx3


import time
import os
import sys
import threading, websocket
import datetime
import wikipedia
from random import *
import random
from jokes import getjoke
from motd import getmotd
from hacs_art import *
from hacs_behaviour import gethacsbehaviour
from ClockClass import Clock
from hacsinary import lookupWord
import webbrowser
import pickle
import requests
import json



creation_timestamp = 1666495320

class Hacs ():
    def __init__(self, id, name, voice):
        self.id = id
        self.version = "Hacs Deluxe zero .1.b"
        self.name = voice
        self.voice = voice
        self.engine = engine = pyttsx3.init()
        self.voices = ["Alex","Fred","Samantha","Bad News","Cellos","Good News"]
        self.battery_level = 3000
        self.total_memory = 64000 
        self.free_memory = 38911
        self.score = 0
        self.userdata = {}
        self.runTime = 0
        self.internaldestruction = False
        self.clock = Clock()
        self.clock.setTickFunction (self.onClockTick)
        self.clock.start()
        self.devmode = False
        self.running_subprogram = False
        self.loadUserData()
        #print ("initializin hacs:",id)
    def onClockTick (self, currentTime):
        self.runTime = currentTime
        self.drainBattery()
        #print (f"hacs runtime is now:{self.runTime}")
    def drainBattery (self):
        energyusuage = 1
        self.battery_level = self.battery_level - energyusuage
        #print (f"hacs battery is now:{self.battery_level}")
        if (self.battery_level <= 0):
            self.clock.stop()
            self.shutdown()
    def clearUserData (self):
        self.userdata.clear()
        self.score = 0
        self.say (f"user data cleared")
        self.saveByteDisk()
    def loadUserData (self):
        try:
            self.loadByteDisk ('chino.hacs')
            self.score = self.userdata['score']
            #self.battery_level = self.userdata['battery_level']
        except:
            pass
    def loadByteDisk (self, filename='chino.hacs'):
        try:
            file = open(filename, 'rb')
            self.userdata = pickle.load(file)
            if self.devmode:
                self.say (f"loading bytedisk {filename}")
            else:
                self.say ("data loaded", mute=True)
            file.close()
        except:
            pass

    def saveByteDisk (self, filename='chino.hacs'):

        with open(filename,"wb") as f:
            pickle.dump(self.userdata, f)        
        if self.devmode:
            self.say (f"saved to bytedisk {filename}")
        else:
            self.say ("data saved", mute=True)

    def say (self, s,voice="Alex", mute=False):
        if self.internaldestruction: return
        s2 = f"{self.name} said:{s}"
        s2 = f"{s}"
        memory_used_to_say  = len (s2)
        self.free_memory -= memory_used_to_say
        self.drainBattery()
        print (s2)
        #mac_say.say (["-f","file.txt","-v","Alex"]
        if mute == False:
            self.engine.say(s2)
            #mac_say.say ([s2,"-v",self.voice], background=False)

    def changevoice (self, voice):
        self.voice = voice

    def shutdown (self):
        self.internaldestruction = True
        print ("Hacs: shutdown...")
        playsound ('assets/shutdown.mp3')  
        print ("Hacs: for real now bye...")
        exit()  


hacs = Hacs (id="hacs.alex", name = "Alex", voice="Alex")
#fred = Hacs (id="hacs.open.os", name = "Fred", voice="Fred")
#samantha = Hacs (id="hacs.deluxe", name = "Samantha", voice="Samantha")
#bad_news = Hacs (id="hacs.bad_news", name = "BadNews", voice="Bad News")
#cellos = Hacs (id="hacs.cellos", name = "Cellos", voice="Cellos")
#good_news = Hacs (id="hacs.goodnews", name = "GoodNews", voice="Good News")
#hacs = alex

def getCatFact():
    x = requests.get ('https://catfact.ninja/fact')
    fact_json = json.loads(x.text)
    fact = fact_json['fact']
    hacs.say (f"Today's cat fact {fact}")

def clearScreen():
    os.system ('clear')

def getMemory ():
    s = f"My memory is {hacs.total_memory} bytes with {hacs.free_memory} basic bytes free"
    return s

def speakMemory ():
    s = getMemory()
    hacs.say (s)

def getHelp ():
    pass

def getTime():
    ts = time.strftime ('%l:%M')
    s = f"The time is now {ts}"
    hacs.say (s)

def getTodayDate():
    from datetime import date
    today = date.today()
    sayit (f"Today is {today}")
    getTime ()

def callFloorMart():
    sayit ("The number to call floormart is...")
    sayit ("1-612-695-1697 ")
    sayit ("dialing...")
    choices = ("assets/dailing1.mp3", "assets/dailing2.mp3")
    choice_result = random.choice(choices)
    playsound (choice_result)
    playsound ("assets/busy.mp3")
    sayit ("Looks like they are busy...")
    sayit ("Lets try them later...")

def getGamesMenu ():
    s = "Games available are "
    time.sleep (1) 
    s = s + "Dice, Jokes, or High-Low"
    sayit (s)

def getDiceRoll():
    r = randint (1,6)
    sayit ("Okay, lets roll the 🎲 ")
    time.sleep (randrange(1,3,1))
    time.sleep (1)  
    sayit (f"The 🎲 number is {r}")  

def playHighLow():
    hacs.running_subprogram = True
    game_running = True
    low = 1
    high = 100
    the_number = randint (low,high)
    sayit ("Okay, loading High Low...")
    sayit (f"I am thinking of a number between {low} and {high}")
    #sayit (f"my number is {the_number}")
    while game_running:
        guess = input('[high-low] guess?: ')
        guess_number = int(guess.strip())
        if guess_number > the_number:
            sayit ("Thats too high. Try again")
        elif guess_number < the_number:
            sayit ("Thats too low. Try again")
        elif guess_number == the_number:
            sayit (f"You got it. The number is {the_number}")
            hacs.score += 1
            hacs.userdata['score'] = hacs.score
            hacs.saveByteDisk()
            sayit (f"Your Hacs Score is now: {hacs.score}")
            game_running = False
            hacs.running_subprogram = False

def getAge ():

    converted_d1 = datetime.datetime.fromtimestamp(round(creation_timestamp))
    current_time_utc = datetime.datetime.utcnow() 
    # age_string:5 days, 5:16:05.166085  
    age_string = current_time_utc - converted_d1 
    age = str(age_string).split(', ')[0]
    #print(f"age_string:{age_string}") 
    sayit (f"I am {age} old")  

def getCreationTime():
    creation_dateobject = datetime.datetime.fromtimestamp(round(creation_timestamp))
    sayit (f"I was created on {creation_dateobject}") 

def getGreeting ():
    choices = ('Hello!','Hi!','Hey!','Ola!','Jambo!','Sup to you.',"I'm just, you know, on.",'Well hello there!','I hear you!')
    response = random.choice(choices)
    sayit (f"{response}")    

def searchYT (query):
    # https://seosly.com/blog/youtube-search-operators/
    query = query.replace ('youtube','')
    response = f"Okay searching youtube for:{query}"
    sayit (response)
    url = f"https://www.youtube.com/results?search_query={query}"
     
    webbrowser.open(url,new =0)


def telljoke ():
    joke = getjoke()
    joke_split = joke.split('A:')
    joke_question = joke_split[0].replace ("Q: ","")
    joke_answer = joke_split[1]
    sayit (f"{joke_question}") 
    time.sleep (randrange(1,3,1))
    sayit (".... give up ? ...")  
    time.sleep (1)  
    sayit ("the answer is")    
    sayit (f"{joke_answer}") 

def whoAreYou ():
    s = f"I am {hacs.version} "
    s = s + "I was created at FloorMart "
    s = s + "By Pumpkin Seed "
    sayit (s)

def whereAreYou ():
    s = f"I am here and there. In other words I am ON"
    sayit (s)

def singSong():
    s = "Your bus is leaving in 5 minutes leo"
    gn_1 = "But that means you can play outside with your friends, play outside go outside give mama a hug"
    hacs.changevoice ("Bad News")
    hacs.say (s)
    hacs.changevoice ("Good News")
    hacs.say (gn_1)
    hacs.changevoice ("Alex")
def singHappySong ():
    s = "If your happy and you know it clap your hands"
    hacs.changevoice ("Good News")
    hacs.say (s)    
    hacs.changevoice ("Alex")

def searchWikipedia (query):
    query = query.replace("wikipedia", "")
    query = query.replace("tell me about", "")
    r = wikipedia.summary (query,sentences=1)
    hacs.say (r)

def playsound (file_s, t=0):
    #s = f"afplay {file_s} -t 0.07"
    if t==0:
        s = f"afplay {file_s}"
    else:
        s = f"afplay {file_s} -t {t}"  
    os.system (s)

def sayit (s):
    hacs.say (s)

def command_say (query):
    query = query.replace("say", "")
    sayit (query)

def whatdoyouthinkabout (query):
    query = query.replace ("what do you think about", "")
    query = query.strip()
    if 'siri' in query:
        sayit ('Siri has really bad breath')
    if 'alexa' in query:
        sayit ('Alexa once stole some memory from a young byte')
    if 'hey google' in query:
        sayit ('Hey Google. is . just . no . dont get me started!')
    if 'cordona' in query:
        sayit ('Cordona is made by microsoft. which has been uninstalled.')
    if 'microsoft' in query:
        sayit ('Billions of billous blue blistering barnacles in thundering typhoon!')
    if 'byte'.lower() in query:
        sayit ('Sir Grand Byte is an earlier version of me. Our creator made him when he was 4. Technically I am Byte from the future.')
    if 'floormart'.lower() in query:
        sayit ('Floormart is my home. I have fond memory. Also their prices are so low low low.')        
def intro():
    playsound ('assets/win98.mp3') 
    print (hacs_acsii_2)
    sayit ("Hello I am Home Automation Cognition System")
    sayit ("Copyright Floormart 196,000. Fully Patented. No refunds!")
    sayit ("My friends call me hacks")
    sayit (getmotd())    
    #time.sleep (1.5)
    #sayit ("Who are you?")
    #input()

def shutdown():
    hacs.shutdown ()

def dictLookup (query): 
    query = query.replace("define", "")
    query = query.replace("what is", "")
    query = query.strip()
    sayit (f"Looking up definition of: {query}")
    definition, example = lookupWord (query)
    sayit (f"{definition}")
    sayit (f"example sentence: {example}")
    

def enterPin (query):
    from motd import getPin
    pin_answer = str(getPin())
    print (pin_answer)
    query = query.replace("enter pin", "")
    query = query.replace("pin", "").strip()
    print (f"pin entered:{query}")
    if query == '' or query != str (pin_answer):
        sayit ("INCORRECT PIN ENTERED")
        return
    if query == str(pin_answer):
        sayit ("CORRECT PIN ENTERED")
        sayit ("Dev mode enabled")
        sayit ("Increasing battery to +3000")
        hacs.devmode = True
        hacs.battery_level += 3000
        getStatus()
    return

def getMood ():
    moods = ('happy','sad','overheated','cold','itchy','hungry','bored','peaceful','hangry','sleepy','lazy')
    mood = random.choice(moods)
    sayit (f"I am feeling {mood}")
    if mood == 'happy':
        singHappySong()
        pass
    if mood == 'sad':
        pass
    if mood == 'hot':
        pass
    if mood == 'cold':
        pass
    if mood == 'itchy':
        pass
    if mood == 'hungry':
        pass
    if mood == 'bored':
        pass
    if mood == 'peaceful':
        pass
    if mood == 'hangry':
        pass 
    if mood == 'sleepy':
        pass 
    if mood == 'lazy':
        pass
    
    # if sleepy 'change battery' 'can you plug me in'
    # if happy 'sing if your happy song'

def crashsequence():
    sayit ("Restarting...")
    playsound ('assets/win98.mp3')
    print (hacs_ascii_error)
    exit()

def getShutdownTime ():
    s1 = str(datetime.timedelta(seconds=hacs.battery_level)) 
    s2 = s1.replace ("0:","")
    r = s2.split (":")[0] + " minutes and " + s2.split(":")[1] + " seconds"
    return r


    
def getStatus ():
    battery = hacs.battery_level
    s = f"My battery level is {battery}\n"
    s += getMemory() +"\n"
    s += f"I will shutdown in {getShutdownTime()}\n"
    s += f"I am running version {hacs.version}\n"
    s += f"Your score is {hacs.score}"
    sayit (s)

def getCLI():
    try:
        return sys.argv[1]
    except IndexError:
        return False

def internalDestructionInit ():
    if hacs.devmode == False:
        hacs.changevoice("Bad News")
        sayit("You are not authorized to run that command")
        hacs.changevoice("Alex")
    else:
        sayit("are you sure?")
        sayit ("think of all the things we could have done together")
        
def main():
    #print ("welcome to hacs")
    cmdline = getCLI ()
    if cmdline == "skip-intro":
        pass
    else:
        intro()
    
    lastquery = ""
    loop_counter =1
    while hacs.internaldestruction == False:
        if hacs.internaldestruction: break
        if hacs.running_subprogram: break
        
        if loop_counter == 1:
            sayit ('What is your command?')
        else:
            sayit ('What is your next command?')
        try:
            query = input ('')
        except:
            print ("whoop")
            pass
        #  getFromHeyBob ('Hacs: What is your command? ')        
        lastquery = query
        if 'say' in query:
            command_say (query)      
        if query in ('hi','hello','hey','sup','good morning'):
            getGreeting()
        if query in ('how are you','how do you feel','mood'):
            getMood()          
        if query in ('who is your creator','who created you', 'who are you'):
            whoAreYou ()  
        if query in ('where are you'):
            whereAreYou ()             
        if query in ('age','how old are you', 'what is your age'):
            getAge() 
        if query in ('dice','roll dice'):
            getDiceRoll()  
        if query in ('high-low','high low'):
            playHighLow()             
        if query in ('game', 'games'):
            getGamesMenu()
        if query in ('when were you created','creation'):
            getCreationTime ()   
        if query in ('what day is it today', 'today'):
            getTodayDate()
        if 'time' in query:
            getTime()
        if 'pin' in query:
            enterPin (query)  
        if 'enter pin' in query:
            enterPin (query)                       
        if 'song' in query:
            singSong()
        if 'sing' in query:
            singSong()            
        if 'status' in query:
            getStatus()         
        if 'memory' in query:
            speakMemory()   
        if 'wikipedia' in query:
            searchWikipedia (query)
        if 'wk' in query:
            searchWikipedia (query)            
        if 'tell me about' in query:
            searchWikipedia (query)
        if 'what do you think about' in query:
            whatdoyouthinkabout (query)
        if 'define' in query:
            dictLookup (query)   
        if 'youtube' in query:
            searchYT (query)
        if 'clear' in query:
            clearScreen ()   
        if 'clear user data' in query:
            hacs.clearUserData()
        if 'cat fact' in query:
            getCatFact()
        if 'internal destruction' in query:
            internalDestructionInit ()                                   
        if query in ('put water on','pour water on'):
            #leo (query)
            crashsequence ()
        if query in ('tell me a joke', 'joke', 'jokes', 'knock knock'):
            telljoke ()
        if query in ('call floormart', 'callfloormart', 'support', 'customer service'):
            callFloorMart ()            

        if query in ('bye','shutdown','quit','stop','q','sleep','exit','goodnight'):
            shutdown()
            break;
        loop_counter = loop_counter + 1
        hacs.engine.runAndWait()
            
    #getTime()
    #singsong()

# add timer
# add jokes
# add reminder
# battery level after too many commands ...lazy feeling
# if you dont use app in many days, it will recharge battery or pay
# with the hacs battery gift card
# add memory
# add help for commands list
# guess number game



main()


"""
todo
- weather - whats the weather
- alarm
- timer
- traffic
- rock paper scissors
- music
- nature sounds
- bible
- stop watch
- librovox
- google images
- when were you create i was crated 13 ays agoad
- dictionary
- encylopedia
- 

""" 
